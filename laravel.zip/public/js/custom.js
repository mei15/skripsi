$('.nav-user').click(function() {
    $(this).closest('div').find('.profile-dropdown').slideToggle(200);
}); 